<script setup>
import { computed, reactive, ref } from 'vue'
import {
  classLifecycleStatus,
  endCurrentClass,
  exportFullBackup,
  getClassDataSummary,
  getClassProfile,
  getEndClassClearedData,
  getEndClassPreservedSettings,
  getFirebaseTestResult,
  getFirebaseWizardProgress,
  getPersonalFirebaseConfig,
  getStorageMode,
  importFullBackup,
  removePersonalFirebaseConfig,
  saveClassProfile,
  saveFirebaseTestResult,
  saveFirebaseWizardProgress,
  savePersonalFirebaseConfig,
  setStorageMode
} from '../services/dataCenter'
import { testTeacherFirebase } from '../services/firebase'

// ✅ HUA_END_CLASS_NO_ARCHIVE_PAGE_20260712：取消封存中心，改為可選備份＋安全結束班級；Firebase 精靈入口去重。
const profile = reactive(getClassProfile())
const storageMode = ref(getStorageMode())
const classSummary = ref(getClassDataSummary())
const localRiskAccepted = ref(localStorage.getItem('classHelperLocalRiskAcknowledgedV1') === 'true')
const notice = ref('')
const importInput = ref(null)
const endClassOpen = ref(false)
const endClassConfirmText = ref('')
const endClassAcknowledged = ref(false)
const endClassBackupDownloaded = ref(false)
const endClassBusy = ref(false)
const clearedDataItems = getEndClassClearedData()
const preservedSettingItems = getEndClassPreservedSettings()
const firebaseConfigText = ref(getPersonalFirebaseConfig() ? JSON.stringify(getPersonalFirebaseConfig(), null, 2) : '')
const firebaseConfigured = ref(Boolean(getPersonalFirebaseConfig()))
const wizardOpen = ref(false)
const wizardBusy = ref(false)
const wizard = reactive(getFirebaseWizardProgress())
const testResult = ref(getFirebaseTestResult())
const rulesCopied = ref(false)

const FIREBASE_RULES = `{
  "rules": {
    ".read": false,
    ".write": false,
    "users": {
      "$uid": {
        ".read": "auth != null && auth.uid === $uid",
        ".write": "auth != null && auth.uid === $uid"
      }
    }
  }
}`

const steps = [
  { number: 1, title: '建立自己的 Firebase 專案', short: '建立專案' },
  { number: 2, title: '登記班級助手網頁', short: '建立 Web App' },
  { number: 3, title: '建立雲端資料庫', short: '建立 Database' },
  { number: 4, title: '啟用 Google 登入', short: '啟用登入' },
  { number: 5, title: '設定資料安全規則', short: '安全規則' },
  { number: 6, title: '貼上專案連線設定', short: '貼上 Config' },
  { number: 7, title: '登入並測試連線', short: '測試連線' }
]

const lifecycle = computed(() => classLifecycleStatus(profile))
const lifecycleClass = computed(() => `lifecycle-${lifecycle.value.state}`)
const currentStepInfo = computed(() => steps.find(item => item.number === wizard.currentStep) || steps[0])
const wizardProgressText = computed(() => `${wizard.completedSteps.length} / ${steps.length} 已完成`)
const cycleLabel = computed(() => ({
  'one-semester': '一學期',
  'one-year': '一年',
  'two-years': '兩年',
  custom: '自訂日期'
}[profile.cycleType] || '自訂日期'))
const endClassConfirmPhrase = computed(() => profile.name.trim() || '結束班級')
const canEndClass = computed(() => (
  endClassAcknowledged.value &&
  endClassConfirmText.value.trim() === endClassConfirmPhrase.value &&
  !endClassBusy.value
))

function showNotice(message) {
  notice.value = message
  window.setTimeout(() => { if (notice.value === message) notice.value = '' }, 3000)
}

function persistWizard() {
  const saved = saveFirebaseWizardProgress(wizard)
  Object.assign(wizard, saved)
}

function openWizard(reset = false) {
  if (reset && !confirm('要重新開始設定精靈嗎？已保存的 Firebase Config 不會被刪除。')) return
  if (reset) Object.assign(wizard, { currentStep: 1, completedSteps: [], acknowledged: false })
  persistWizard()
  wizardOpen.value = true
}

function closeWizard() {
  if (wizardBusy.value) return
  persistWizard()
  wizardOpen.value = false
}

function goToStep(step) {
  wizard.currentStep = step
  persistWizard()
}

function completeCurrentStep() {
  if (!wizard.completedSteps.includes(wizard.currentStep)) wizard.completedSteps.push(wizard.currentStep)
  if (wizard.currentStep < 7) wizard.currentStep += 1
  persistWizard()
}

function previousStep() {
  if (wizard.currentStep > 1) wizard.currentStep -= 1
  persistWizard()
}

function applyCyclePreset() {
  if (profile.cycleType === 'custom') return
  const start = new Date(`${profile.startDate}T00:00:00`)
  if (Number.isNaN(start.getTime())) return
  const end = new Date(start)
  if (profile.cycleType === 'one-semester') end.setMonth(end.getMonth() + 6)
  if (profile.cycleType === 'one-year') end.setFullYear(end.getFullYear() + 1)
  if (profile.cycleType === 'two-years') end.setFullYear(end.getFullYear() + 2)
  end.setDate(end.getDate() - 1)
  profile.endDate = end.toISOString().slice(0, 10)
}

function saveProfile() {
  Object.assign(profile, saveClassProfile(profile))
  classSummary.value = getClassDataSummary()
  showNotice('班級週期已儲存')
}

function selectLocalMode() {
  if (!localRiskAccepted.value) return showNotice('請先勾選已了解本機模式風險')
  localStorage.setItem('classHelperLocalRiskAcknowledgedV1', 'true')
  storageMode.value = setStorageMode('local')
  showNotice('已使用本機模式')
}

function selectFirebaseMode() {
  if (!testResult.value?.ok) {
    wizardOpen.value = true
    showNotice('請先完成設定精靈與連線測試')
    return
  }
  storageMode.value = setStorageMode('firebase')
  showNotice('已選擇個人 Firebase 模式')
}

function handleExport() {
  exportFullBackup()
  showNotice('班級備份已下載')
}

function openImportPicker() { importInput.value?.click() }

async function handleImport(event) {
  const file = event.target.files?.[0]
  event.target.value = ''
  if (!file) return
  try {
    const replace = confirm('要以備份內容取代目前資料嗎？\n\n確定：先清除目前資料再還原。\n取消：保留目前資料並合併。')
    await importFullBackup(file, { replace })
    showNotice('備份已匯入，頁面即將重新整理')
    window.setTimeout(() => window.location.reload(), 800)
  } catch (error) {
    showNotice(error?.message || '匯入失敗')
  }
}

function openEndClassDialog() {
  endClassConfirmText.value = ''
  endClassAcknowledged.value = false
  endClassBackupDownloaded.value = false
  endClassOpen.value = true
}

function closeEndClassDialog() {
  if (endClassBusy.value) return
  endClassOpen.value = false
}

function handleEndClassBackup() {
  exportFullBackup()
  endClassBackupDownloaded.value = true
  showNotice('班級備份已下載；是否保留由老師自行決定')
}

function handleEndClass() {
  if (!canEndClass.value) return
  endClassBusy.value = true
  try {
    endCurrentClass()
    showNotice('班級資料已清除，教師設定已保留')
    endClassOpen.value = false
    window.setTimeout(() => window.location.reload(), 900)
  } catch (error) {
    console.error(error)
    showNotice(error?.message || '結束班級失敗，資料尚未清除')
    endClassBusy.value = false
  }
}

function saveFirebaseConfigOnly() {
  try {
    const clean = savePersonalFirebaseConfig(firebaseConfigText.value)
    firebaseConfigText.value = JSON.stringify(clean, null, 2)
    firebaseConfigured.value = true
    if (!wizard.completedSteps.includes(6)) wizard.completedSteps.push(6)
    persistWizard()
    showNotice('個人 Firebase 設定已儲存在這台裝置')
    return clean
  } catch (error) {
    showNotice(error?.message || 'Firebase Config 格式錯誤')
    return null
  }
}

async function runConnectionTest() {
  const config = saveFirebaseConfigOnly()
  if (!config) return
  wizardBusy.value = true
  try {
    const result = await testTeacherFirebase(config)
    testResult.value = saveFirebaseTestResult(result)
    firebaseConfigured.value = true
    if (!wizard.completedSteps.includes(7)) wizard.completedSteps.push(7)
    wizard.currentStep = 7
    persistWizard()
    storageMode.value = setStorageMode('firebase')
    showNotice(`連線成功：${result.email || result.displayName || 'Google 帳號'}`)
  } catch (error) {
    console.error(error)
    const messages = {
      'auth/unauthorized-domain': '目前網址尚未加入 Firebase 授權網域，請回到第 4 步設定。',
      'auth/operation-not-allowed': '尚未啟用 Google 登入，請回到第 4 步。',
      'auth/popup-closed-by-user': '你關閉了 Google 登入視窗，資料沒有變動。',
      'PERMISSION_DENIED': '資料庫拒絕存取，請檢查第 5 步安全規則。'
    }
    showNotice(messages[error?.code] || messages[error?.message] || error?.message || '連線測試失敗')
  } finally {
    wizardBusy.value = false
  }
}

async function copyRules() {
  try {
    await navigator.clipboard.writeText(FIREBASE_RULES)
    rulesCopied.value = true
    showNotice('安全規則已複製')
    setTimeout(() => { rulesCopied.value = false }, 1800)
  } catch { showNotice('無法自動複製，請手動選取規則') }
}

function removeFirebaseConfig() {
  if (!confirm('移除這台裝置上的 Firebase 設定？這不會刪除 Firebase 專案中的資料。')) return
  removePersonalFirebaseConfig()
  storageMode.value = 'local'
  firebaseConfigText.value = ''
  firebaseConfigured.value = false
  testResult.value = null
  Object.assign(wizard, { currentStep: 1, completedSteps: [], acknowledged: false })
  persistWizard()
  showNotice('已移除個人 Firebase 設定並改回本機模式')
}

</script>

<template>
  <div class="page wide-page data-center-page">
    <div class="page-title-row">
      <div>
        <h2>💾 資料與同步</h2>
        <p>老師永遠擁有自己的資料。這裡管理儲存方式、個人 Firebase、班級備份與班級週期。</p>
      </div>
      <span class="data-owner-badge">🔒 開發者不保存班級資料</span>
    </div>

    <section class="data-principle-card">
      <strong>班級助手的資料原則</strong>
      <p>預設使用本機模式；需要跨裝置時，由老師連接自己建立的 Firebase。切換模式不會偷偷刪除資料；只有老師主動完成「結束班級」確認時，才會清除目前班級資料。</p>
    </section>

    <div class="data-center-grid">
      <section class="card data-section storage-section">
        <div class="data-section-head">
          <div><span class="data-kicker">資料儲存方式</span><h3>選擇適合自己的模式</h3></div>
          <span class="mode-pill">目前：{{ storageMode === 'firebase' ? '個人 Firebase' : '本機模式' }}</span>
        </div>
        <div class="storage-mode-grid">
          <article class="mode-card" :class="{ active: storageMode === 'local' }">
            <div class="mode-card-title-row">
              <span class="mode-icon">💻</span>
              <h4>本機模式</h4>
              <span v-if="storageMode === 'local'" class="mode-selected-badge">✓ 目前使用</span>
            </div>
            <p>立即可用，不需登入；資料只存在目前瀏覽器與裝置。</p>
            <ul><li>適合單一裝置使用</li><li>不需設定 Firebase</li><li>應定期下載班級備份</li></ul>
            <label class="risk-check"><input v-model="localRiskAccepted" type="checkbox" /><span>我了解清除瀏覽器資料、重灌或換裝置可能造成資料無法復原。</span></label>
            <button type="button" class="data-primary mode-select-button" @click="selectLocalMode">選擇本機模式</button>
          </article>
          <article class="mode-card firebase-mode-card" :class="{ active: storageMode === 'firebase' }">
            <div class="mode-card-title-row">
              <span class="mode-icon">☁️</span>
              <h4>個人 Firebase 模式</h4>
              <span v-if="storageMode === 'firebase'" class="mode-selected-badge">✓ 目前使用</span>
            </div>
            <p>資料存放在老師自己建立、自己管理的 Firebase 專案。</p>
            <ul><li>可跨電腦與手機同步</li><li>容量與權限由老師本人管理</li><li>開發者無法查看或復原資料</li></ul>
            <span class="setup-state" :class="{ ready: testResult?.ok }">{{ testResult?.ok ? `✅ 已連線：${testResult.projectId}` : firebaseConfigured ? '設定已保存，尚未測試' : '尚未完成設定' }}</span>
            <div class="mode-card-actions">
              <button type="button" class="data-secondary" @click="openWizard(false)">{{ firebaseConfigured ? '查看／繼續設定' : '開始設定精靈' }}</button>
              <button type="button" class="data-primary" @click="selectFirebaseMode">選擇個人 Firebase</button>
            </div>
            <div v-if="firebaseConfigured" class="firebase-card-tools">
              <button type="button" class="data-text-button" @click="openWizard(true)">重新設定</button>
              <button type="button" class="data-text-button danger" @click="removeFirebaseConfig">移除這台裝置的設定</button>
            </div>
          </article>
        </div>
      </section>

      <section class="card data-section backup-section">
        <div class="data-section-head"><div><span class="data-kicker">可選安全網</span><h3>班級備份與還原</h3></div><span class="data-icon">💾</span></div>
        <p>備份只包含目前班級資料；不會收入 Firebase Config、登入測試、儲存模式或裝置偏好。</p>
        <div class="backup-actions"><button type="button" class="data-primary" @click="handleExport">下載班級備份</button><button type="button" class="data-secondary" @click="openImportPicker">匯入備份</button><input ref="importInput" class="sr-only" type="file" accept="application/json,.json" @change="handleImport" /></div>
        <p class="data-warning">備份完全自願。匯入時只處理班級資料，不會覆蓋老師的 Firebase 與介面設定。</p>
      </section>
    </div>

    <section class="card data-section lifecycle-section">
      <div class="data-section-head"><div><span class="data-kicker">班級生命週期</span><h3>依實際任教期間提醒</h3></div><span class="lifecycle-status" :class="lifecycleClass">{{ lifecycle.message }}</span></div>
      <div class="lifecycle-form">
        <label><span>班級名稱</span><input v-model.trim="profile.name" placeholder="例如：三年一班" /></label>
        <label><span>開始日期</span><input v-model="profile.startDate" type="date" @change="applyCyclePreset" /></label>
        <label><span>任教週期</span><select v-model="profile.cycleType" @change="applyCyclePreset"><option value="one-semester">一學期</option><option value="one-year">一年</option><option value="two-years">兩年</option><option value="custom">自訂日期</option></select></label>
        <label><span>預計結束日期</span><input v-model="profile.endDate" type="date" :disabled="profile.cycleType !== 'custom'" /></label>
        <label><span>提前提醒</span><select v-model.number="profile.reminderDays"><option :value="14">14 天前</option><option :value="30">30 天前</option><option :value="60">60 天前</option><option :value="90">90 天前</option></select></label>
      </div>
      <div class="lifecycle-footer"><span>目前設定：{{ cycleLabel }}。到期只提醒「延長」或「結束班級」，絕不自動刪除。</span><button type="button" class="data-primary" @click="saveProfile">儲存班級週期</button></div>
    </section>

    <section class="card data-section end-class-section">
      <div class="data-section-head">
        <div><span class="data-kicker">換班時使用</span><h3>結束目前班級</h3></div>
        <span class="end-class-count">{{ classSummary.studentCount }} 位學生・{{ classSummary.dataKeyCount }} 組班級資料</span>
      </div>
      <p>不建立站內歷史封存。老師換班時，可直接清除目前班級資料；需要留存的人，再自行下載一份班級備份。</p>
      <div class="end-class-choice-grid">
        <div class="end-class-list clear-list">
          <strong>結束後清除</strong>
          <span v-for="item in clearedDataItems" :key="item">✕ {{ item }}</span>
        </div>
        <div class="end-class-list keep-list">
          <strong>仍會保留</strong>
          <span v-for="item in preservedSettingItems" :key="item">✓ {{ item }}</span>
        </div>
      </div>
      <div class="end-class-actions">
        <button type="button" class="data-secondary" @click="handleExport">先下載班級備份（可選）</button>
        <button type="button" class="data-danger end-class-open-button" @click="openEndClassDialog">結束這個班級</button>
      </div>
      <p class="data-warning">班級助手不會替老師保留歷屆學生資料。清除完成後無法從網站內復原，除非老師先前自行保存備份檔。</p>
    </section>

    <div v-if="endClassOpen" class="end-class-overlay" @click.self="closeEndClassDialog">
      <section class="end-class-modal" role="dialog" aria-modal="true" aria-labelledby="endClassTitle">
        <button class="end-class-close" type="button" :disabled="endClassBusy" @click="closeEndClassDialog">×</button>
        <div class="end-class-modal-icon">🧹</div>
        <h2 id="endClassTitle">確定結束「{{ profile.name || '目前班級' }}」？</h2>
        <p>這會清除學生名單與目前班級的操作紀錄，但保留 Firebase、介面偏好，以及可重複使用的作息與工作模板。</p>

        <div class="end-class-backup-box">
          <div>
            <strong>備份不是必填</strong>
            <span>平常不需要保留舊班資料，可以直接略過。</span>
          </div>
          <button type="button" class="data-secondary" @click="handleEndClassBackup">{{ endClassBackupDownloaded ? '✓ 已下載一份備份' : '下載備份（可選）' }}</button>
        </div>

        <label class="end-class-acknowledge">
          <input v-model="endClassAcknowledged" type="checkbox" />
          <span>我了解這些班級資料將永久清除，且網站內沒有封存可供還原。</span>
        </label>

        <label class="end-class-confirm-field">
          <span>請輸入「<strong>{{ endClassConfirmPhrase }}</strong>」確認</span>
          <input v-model="endClassConfirmText" :placeholder="endClassConfirmPhrase" autocomplete="off" />
        </label>

        <div class="end-class-modal-actions">
          <button type="button" class="data-secondary" :disabled="endClassBusy" @click="closeEndClassDialog">取消</button>
          <button type="button" class="data-danger" :disabled="!canEndClass" @click="handleEndClass">{{ endClassBusy ? '正在清除…' : '永久清除並建立空白班級' }}</button>
        </div>
      </section>
    </div>

    <div v-if="wizardOpen" class="firebase-wizard-overlay" @click.self="closeWizard">
      <section class="firebase-wizard-modal" role="dialog" aria-modal="true" aria-label="Firebase 設定精靈">
        <button class="wizard-close" type="button" :disabled="wizardBusy" @click="closeWizard">×</button>
        <header class="wizard-header"><div><span>☁️ 個人雲端設定</span><h2>{{ currentStepInfo.number }}. {{ currentStepInfo.title }}</h2><p>設定只保存在這台裝置，班級助手開發者不會收到你的 Firebase Config 或班級資料。</p></div><strong>{{ wizardProgressText }}</strong></header>
        <div class="wizard-steps"><button v-for="step in steps" :key="step.number" type="button" :class="{ done: wizard.completedSteps.includes(step.number), active: wizard.currentStep === step.number }" @click="goToStep(step.number)"><span>{{ wizard.completedSteps.includes(step.number) ? '✓' : step.number }}</span>{{ step.short }}</button></div>

        <div class="wizard-content">
          <template v-if="wizard.currentStep === 1"><h3>建立老師自己的雲端專案</h3><ol><li>開啟 Firebase Console，使用老師自己的 Google 帳號。</li><li>按「建立專案」，名稱可用「班級助手－班級名稱」。</li><li>Google Analytics 可依需求選擇，不影響班級助手同步。</li></ol><a class="wizard-link" href="https://console.firebase.google.com/" target="_blank" rel="noopener noreferrer">開啟 Firebase Console ↗</a></template>
          <template v-else-if="wizard.currentStep === 2"><h3>新增 Web App</h3><ol><li>在專案總覽按 Web 圖示「&lt;/&gt;」。</li><li>暱稱可填「班級助手」。</li><li>不必勾選 Firebase Hosting；完成註冊即可。</li><li>先保留畫面中的 <code>firebaseConfig</code>，第 6 步會使用。</li></ol></template>
          <template v-else-if="wizard.currentStep === 3"><h3>建立 Realtime Database</h3><ol><li>左側「建構」→「Realtime Database」。</li><li>按「建立資料庫」，地區選離自己較近的位置。</li><li>可先選鎖定模式；第 5 步會貼上正式安全規則。</li><li>建立後確認 Web App 設定中出現 <code>databaseURL</code>。</li></ol></template>
          <template v-else-if="wizard.currentStep === 4"><h3>啟用 Google 登入</h3><ol><li>左側「建構」→「Authentication」→「開始使用」。</li><li>在登入方式啟用「Google」。</li><li>填入專案支援信箱並儲存。</li><li>到「設定」→「已授權的網域」，加入你實際使用班級助手的網域；本機測試通常使用 <code>localhost</code>。</li></ol></template>
          <template v-else-if="wizard.currentStep === 5"><h3>貼上安全規則</h3><p>這份規則只允許已登入的老師讀寫自己 UID 路徑下的資料。</p><pre class="rules-box">{{ FIREBASE_RULES }}</pre><button type="button" class="data-secondary" @click="copyRules">{{ rulesCopied ? '✓ 已複製' : '複製安全規則' }}</button><ol><li>Realtime Database →「規則」。</li><li>全選舊內容，貼上上方規則。</li><li>確認沒有紅色錯誤後按「發布」。</li></ol></template>
          <template v-else-if="wizard.currentStep === 6"><h3>貼上 Firebase Config</h3><p>可直接貼上整段 <code>const firebaseConfig = { ... }</code>，班級助手會自動擷取大括號內容。</p><textarea v-model="firebaseConfigText" class="wizard-config-textarea" spellcheck="false" placeholder="const firebaseConfig = {\n  apiKey: '...',\n  authDomain: '...',\n  databaseURL: '...',\n  projectId: '...',\n  appId: '...'\n}"></textarea><button type="button" class="data-primary" @click="saveFirebaseConfigOnly">檢查並保存設定</button></template>
          <template v-else><h3>登入並做一次安全測試</h3><p>班級助手會開啟 Google 登入視窗，暫時在 <code>users／你的 UID／systemChecks</code> 寫入測試資料、讀回後立即刪除。</p><div v-if="testResult?.ok" class="wizard-success"><strong>✅ 測試成功</strong><span>{{ testResult.email }}</span><span>專案：{{ testResult.projectId }}</span><span>UID：{{ testResult.uid }}</span></div><button type="button" class="data-primary" :disabled="wizardBusy" @click="runConnectionTest">{{ wizardBusy ? '正在登入與測試…' : testResult?.ok ? '重新測試連線' : '登入 Google 並測試' }}</button></template>
        </div>

        <footer class="wizard-footer"><button type="button" class="data-secondary" :disabled="wizard.currentStep === 1 || wizardBusy" @click="previousStep">上一步</button><span>可以關閉精靈，進度會保留。</span><button v-if="wizard.currentStep < 7" type="button" class="data-primary" :disabled="wizardBusy" @click="completeCurrentStep">我已完成，下一步</button><button v-else type="button" class="data-primary" :disabled="!testResult?.ok || wizardBusy" @click="closeWizard">完成設定</button></footer>
      </section>
    </div>

    <div v-if="notice" class="data-center-toast" role="status">{{ notice }}</div>
  </div>
</template>
