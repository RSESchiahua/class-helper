// ✅ HUA_PERSONAL_FIREBASE_WIZARD_CORE_20260712：每位老師以自己的 Firebase Config 建立、登入並測試個人雲端空間。
import { deleteApp, getApp, getApps, initializeApp } from 'firebase/app'
import {
  GoogleAuthProvider,
  browserLocalPersistence,
  getAuth,
  setPersistence,
  signInWithPopup,
  signOut
} from 'firebase/auth'
import { get, getDatabase, ref, remove, set } from 'firebase/database'

const APP_NAME = 'class-helper-personal'
let currentSignature = ''

function normalizeConfig(config) {
  const source = config && typeof config === 'object' ? config : {}
  return {
    apiKey: String(source.apiKey || '').trim(),
    authDomain: String(source.authDomain || '').trim(),
    databaseURL: String(source.databaseURL || '').trim().replace(/\/$/, ''),
    projectId: String(source.projectId || '').trim(),
    storageBucket: String(source.storageBucket || '').trim(),
    messagingSenderId: String(source.messagingSenderId || '').trim(),
    appId: String(source.appId || '').trim(),
    measurementId: String(source.measurementId || '').trim()
  }
}

function validateConfig(config) {
  const clean = normalizeConfig(config)
  const required = ['apiKey', 'authDomain', 'databaseURL', 'projectId', 'appId']
  const missing = required.filter(key => !clean[key])
  if (missing.length) throw new Error(`Firebase 設定缺少：${missing.join('、')}`)
  if (!/^https:\/\/.+\.(firebaseio\.com|firebasedatabase\.app)$/i.test(clean.databaseURL)) {
    throw new Error('databaseURL 格式不正確，請從 Firebase 的 Web App 設定完整複製')
  }
  return clean
}

function signature(config) {
  const clean = normalizeConfig(config)
  return JSON.stringify({
    apiKey: clean.apiKey,
    authDomain: clean.authDomain,
    databaseURL: clean.databaseURL,
    projectId: clean.projectId,
    appId: clean.appId
  })
}

export async function initializeTeacherFirebase(config) {
  const clean = validateConfig(config)
  const nextSignature = signature(clean)
  let existing = getApps().find(app => app.name === APP_NAME)

  if (existing && currentSignature && currentSignature !== nextSignature) {
    await deleteApp(existing)
    existing = null
  }

  const app = existing || initializeApp(clean, APP_NAME)
  currentSignature = nextSignature
  const auth = getAuth(app)
  await setPersistence(auth, browserLocalPersistence)
  const provider = new GoogleAuthProvider()
  provider.setCustomParameters({ prompt: 'select_account' })
  const database = getDatabase(app)
  return { app, auth, database, provider, config: clean }
}

export async function testTeacherFirebase(config) {
  const services = await initializeTeacherFirebase(config)
  const credential = await signInWithPopup(services.auth, services.provider)
  const user = credential.user
  if (!user?.uid) throw new Error('Google 登入未完成')

  const checkRef = ref(services.database, `users/${user.uid}/systemChecks/wizard`)
  const testValue = {
    ok: true,
    checkedAt: new Date().toISOString(),
    projectId: services.config.projectId
  }

  await set(checkRef, testValue)
  const snapshot = await get(checkRef)
  if (!snapshot.exists() || snapshot.val()?.ok !== true) {
    throw new Error('已登入，但無法讀回測試資料，請檢查 Database 與規則')
  }
  await remove(checkRef)

  return {
    ok: true,
    uid: user.uid,
    email: user.email || '',
    displayName: user.displayName || '',
    projectId: services.config.projectId
  }
}

export async function signOutTeacherFirebase(config) {
  const { auth } = await initializeTeacherFirebase(config)
  await signOut(auth)
}

export function hasTeacherFirebaseApp() {
  return getApps().some(app => app.name === APP_NAME)
}

export function getTeacherFirebaseApp() {
  return hasTeacherFirebaseApp() ? getApp(APP_NAME) : null
}
