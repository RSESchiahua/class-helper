// ✅ HUA_PERSONAL_FIREBASE_GATE_20260712：公開版不再內建開發者 Firebase；未完成個人設定前一律安全使用本機模式。
import { reactive, readonly } from 'vue'
import { exportFullBackup, getPersonalFirebaseConfig, getStorageMode, setStorageMode } from './dataCenter'

export const CLOUD_DATA_UPDATED_EVENT = 'class-helper-cloud-data-updated'
const state = reactive({
  user: null,
  status: 'local-only',
  message: '資料只儲存在這台裝置',
  lastSyncAt: '',
  isOnline: navigator.onLine,
  uid: '',
  permissionDenied: false,
  hasCloudData: false,
  localOnly: true,
  syncMode: getStorageMode(),
  needsModeChoice: false,
  conflictPending: false,
  conflictLocalCount: 0,
  conflictCloudCount: 0
})
export const cloudState = readonly(state)

let observerInstalled = false

export function installLocalStorageObserver() {
  if (observerInstalled) return
  observerInstalled = true
  window.addEventListener('online', () => { state.isOnline = true })
  window.addEventListener('offline', () => { state.isOnline = false })
}

export async function startCloudSync() {
  const config = getPersonalFirebaseConfig()
  const wantsCloud = getStorageMode() === 'firebase'
  if (wantsCloud && config) {
    state.status = 'setup-required'
    state.message = '個人 Firebase 設定已保存；同步連線將由設定精靈下一階段啟用'
    state.syncMode = 'firebase'
    state.localOnly = true
    return
  }
  setStorageMode('local')
  state.status = 'local-only'
  state.message = '資料只儲存在這台裝置'
  state.syncMode = 'local'
  state.localOnly = true
}

export async function chooseLocalStorageMode() {
  setStorageMode('local')
  await startCloudSync()
}

export async function enableCloudSync() {
  if (!getPersonalFirebaseConfig()) throw new Error('請先到資料中心完成個人 Firebase 設定')
  setStorageMode('firebase')
  await startCloudSync()
}

export function downloadFullBackup() { return exportFullBackup() }
export async function signInCloud() { throw new Error('請先完成個人 Firebase 設定精靈') }
export async function signOutCloud() { return true }
export async function retryCloudSync() { return startCloudSync() }
export async function resolveSyncConflict() { return false }
export async function copyCloudUid() { return false }
