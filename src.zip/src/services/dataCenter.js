// ✅ HUA_END_CLASS_NO_ARCHIVE_CORE_20260712：取消站內封存，改為可選備份＋精準結束班級；保留 Firebase 與教師偏好。
export const STORAGE_MODE_KEY = 'classHelperStorageModeV3'
export const CLASS_PROFILE_KEY = 'classHelperClassProfileV1'
export const LEGACY_CLASS_ARCHIVES_KEY = 'classHelperClassArchivesV1'
export const FIREBASE_CONFIG_KEY = 'classHelperPersonalFirebaseConfigV1'
export const FIREBASE_WIZARD_KEY = 'classHelperFirebaseWizardV1'
export const FIREBASE_TEST_KEY = 'classHelperFirebaseTestV1'
export const LOCAL_RISK_ACK_KEY = 'classHelperLocalRiskAcknowledgedV1'

// 這些是「目前班級是誰、發生過什麼」的資料；結束班級時會清除或重設。
const EXACT_CLASS_DATA_KEYS = new Set([
  'students',
  'className',
  CLASS_PROFILE_KEY,
  'classHelperCalendarEvents',
  'classHelperContactBook',
  'classHelperWeeklyScheduleV1',
  'classHelperStatusSchedule',
  'notebookBoardsV2',
  'notebookWeeklyRecordsV2',
  'notebookNotifiedV2',
  'toothbrushRecords',
  'classAssistantPointRecordsV1',
  'classHelperSeatGroupsForPoints',
  'classHelperSeatPlan',
  'classAssistantSeatGroupsV1',
  'classAssistantSeatAssignmentsV1',
  'classAssistantSeatPlanV1',
  'classAssistantSeatsV1',
  'classAssistantSeatMapV1',
  'seatGroups',
  'seatAssignments',
  'seats',
  'classHelperCleaningAssignments',
  'classHelperJobAssignments',
  'classHelperLibraryLoans',
  'classHelperLibraryHistory'
])

// 座位功能曾有數個版本，名稱可能不同；只針對座位資料做窄範圍相容。
const CLASS_DATA_KEY_PATTERNS = [
  /^classHelperSeat/i,
  /^classAssistantSeat/i,
  /^seat(?:Groups|Assignments|Plan|Map|s)$/i
]

const END_ONLY_KEYS = new Set([LEGACY_CLASS_ARCHIVES_KEY])

const TEMPLATE_PRESERVING_KEYS = new Set([
  'classHelperCleaningAssignments',
  'classHelperJobAssignments',
  'classHelperWeeklyScheduleV1'
])

export function todayText() {
  return new Date().toISOString().slice(0, 10)
}

export function defaultClassProfile(name = localStorage.getItem('className') || '') {
  const now = new Date()
  const year = now.getFullYear()
  return {
    id: `class-${Date.now()}`,
    name,
    startDate: `${year}-08-01`,
    endDate: `${year + 1}-07-31`,
    cycleType: 'one-year',
    reminderDays: 30,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
}

function safeJson(raw, fallback) {
  try {
    const value = JSON.parse(raw || '')
    return value ?? fallback
  } catch {
    return fallback
  }
}

function setJson(key, value) {
  localStorage.setItem(key, JSON.stringify(value))
}

export function getStorageMode() {
  return localStorage.getItem(STORAGE_MODE_KEY) === 'firebase' ? 'firebase' : 'local'
}

export function setStorageMode(mode) {
  const normalized = mode === 'firebase' ? 'firebase' : 'local'
  localStorage.setItem(STORAGE_MODE_KEY, normalized)
  return normalized
}

export function getClassProfile() {
  const saved = safeJson(localStorage.getItem(CLASS_PROFILE_KEY), null)
  if (saved && typeof saved === 'object') return { ...defaultClassProfile(), ...saved }
  const profile = defaultClassProfile()
  saveClassProfile(profile)
  return profile
}

export function saveClassProfile(profile) {
  const normalized = {
    ...defaultClassProfile(),
    ...profile,
    reminderDays: Math.max(1, Number(profile?.reminderDays) || 30),
    updatedAt: new Date().toISOString()
  }
  setJson(CLASS_PROFILE_KEY, normalized)
  if (normalized.name) localStorage.setItem('className', normalized.name)
  else localStorage.removeItem('className')
  return normalized
}

export function classLifecycleStatus(profile = getClassProfile()) {
  const end = new Date(`${profile.endDate}T23:59:59`)
  const now = new Date()
  if (Number.isNaN(end.getTime())) return { state: 'unknown', days: null, message: '尚未設定有效的結束日期' }
  const days = Math.ceil((end.getTime() - now.getTime()) / 86400000)
  if (days < 0) return { state: 'ended', days, message: `班級週期已結束 ${Math.abs(days)} 天，可延長日期或結束班級。` }
  if (days <= Number(profile.reminderDays || 30)) return { state: 'ending', days, message: `距離班級結束還有 ${days} 天，請決定延長或結束。` }
  return { state: 'active', days, message: `班級使用中，距離預計結束還有 ${days} 天。` }
}

export function isClassDataKey(key) {
  if (!key) return false
  if (EXACT_CLASS_DATA_KEYS.has(key)) return true
  return CLASS_DATA_KEY_PATTERNS.some(pattern => pattern.test(key))
}

function isEndClassDataKey(key) {
  return isClassDataKey(key) || END_ONLY_KEYS.has(key)
}

export function getClassDataKeys() {
  const keys = []
  for (let index = 0; index < localStorage.length; index += 1) {
    const key = localStorage.key(index)
    if (isClassDataKey(key)) keys.push(key)
  }
  return keys.sort((a, b) => a.localeCompare(b))
}

export function readClassData() {
  const data = {}
  for (const key of getClassDataKeys()) {
    const value = localStorage.getItem(key)
    if (value !== null) data[key] = value
  }
  return data
}

// 保留舊函式名稱，避免既有程式碼失效；現在只讀取班級資料，不再把 Firebase Config 或裝置偏好打包。
export function readAllLocalData() {
  return readClassData()
}

export function getClassDataSummary() {
  const students = String(localStorage.getItem('students') || '')
    .split(/\r?\n/)
    .map(item => item.trim())
    .filter(Boolean)

  const meaningfulDataKeys = getClassDataKeys().filter(key => (
    key !== CLASS_PROFILE_KEY && !TEMPLATE_PRESERVING_KEYS.has(key)
  ))

  return {
    className: localStorage.getItem('className') || getClassProfile().name || '',
    studentCount: students.length,
    dataKeyCount: meaningfulDataKeys.length,
    hasCalendar: Boolean(localStorage.getItem('classHelperCalendarEvents')),
    hasSchedule: Boolean(localStorage.getItem('classHelperWeeklyScheduleV1')),
    hasPointRecords: Boolean(localStorage.getItem('classAssistantPointRecordsV1'))
  }
}

function downloadJson(payload, filename) {
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const anchor = document.createElement('a')
  anchor.href = url
  anchor.download = filename
  document.body.appendChild(anchor)
  anchor.click()
  anchor.remove()
  URL.revokeObjectURL(url)
}

export function exportFullBackup() {
  const profile = getClassProfile()
  const safeName = (profile.name || '未命名班級').replace(/[\\/:*?"<>|]/g, '-')
  const classData = readClassData()
  const payload = {
    format: 'class-helper-class-backup',
    schemaVersion: 2,
    exportedAt: new Date().toISOString(),
    classProfile: profile,
    classData,
    // 同時保留欄位名稱，讓舊版匯入流程仍能辨識；內容仍只包含班級資料。
    localStorage: classData,
    excludes: ['Firebase Config', 'Google 登入狀態', '儲存模式', '設定精靈進度', '裝置與介面偏好']
  }
  downloadJson(payload, `${safeName}_班級備份_${todayText()}.json`)
  return payload
}

function removeClassDataRaw() {
  const keys = []
  for (let index = localStorage.length - 1; index >= 0; index -= 1) {
    const key = localStorage.key(index)
    if (!isEndClassDataKey(key)) continue
    keys.push(key)
    localStorage.removeItem(key)
  }
  return keys
}

function sanitizeImportedClassData(rawData) {
  if (!rawData || typeof rawData !== 'object' || Array.isArray(rawData)) return {}
  return Object.fromEntries(
    Object.entries(rawData)
      .filter(([key, value]) => isClassDataKey(key) && typeof value === 'string')
  )
}

export async function importFullBackup(file, { replace = false } = {}) {
  if (typeof File !== 'undefined' && !(file instanceof File)) throw new Error('請選擇有效的備份檔')
  if (!file || typeof file.text !== 'function') throw new Error('請選擇有效的備份檔')

  const parsed = safeJson(await file.text(), null)
  const acceptedFormat = parsed?.format === 'class-helper-class-backup' || parsed?.format === 'class-helper-backup'
  const sourceData = parsed?.classData || parsed?.localStorage
  if (!parsed || !acceptedFormat || !sourceData) throw new Error('這不是班級助手的班級備份檔')

  const cleanData = sanitizeImportedClassData(sourceData)
  if (!Object.keys(cleanData).length) throw new Error('備份檔中找不到可還原的班級資料')

  if (replace) removeClassDataRaw()
  for (const [key, value] of Object.entries(cleanData)) localStorage.setItem(key, value)

  // 舊備份可能只把 profile 放在外層，仍安全地補回班級資料。
  if (!localStorage.getItem(CLASS_PROFILE_KEY) && parsed.classProfile && typeof parsed.classProfile === 'object') {
    saveClassProfile(parsed.classProfile)
  }

  window.dispatchEvent(new CustomEvent('class-helper-data-imported'))
  return { ...parsed, importedKeys: Object.keys(cleanData) }
}

function preserveCleaningTemplate(raw) {
  const value = safeJson(raw, null)
  if (!Array.isArray(value)) return null
  return value.map(area => ({ ...area, students: [] }))
}

function preserveJobTemplate(raw) {
  const value = safeJson(raw, null)
  if (!Array.isArray(value)) return null
  return value.map(job => ({ ...job, students: [] }))
}

function preserveScheduleTemplate(raw) {
  const value = safeJson(raw, null)
  if (!value || typeof value !== 'object' || !Array.isArray(value.periods) || !value.weekdays) return null

  const periodMap = new Map(value.periods.map(period => [period.id, period]))
  const weekdays = {}

  for (const [dayKey, dayValue] of Object.entries(value.weekdays || {})) {
    weekdays[dayKey] = {}
    for (const [periodId, entry] of Object.entries(dayValue || {})) {
      const period = periodMap.get(periodId)
      if (period?.kind === 'class') {
        weekdays[dayKey][periodId] = { subject: '', icon: '📖', message: '' }
      } else {
        // 早修、打掃、午休等教師慣用流程保留，正式課程內容清空。
        weekdays[dayKey][periodId] = entry && typeof entry === 'object' ? { ...entry } : {}
      }
    }
  }

  return { ...value, weekdays }
}

export function endCurrentClass() {
  const previousProfile = getClassProfile()
  const templates = {
    cleaning: preserveCleaningTemplate(localStorage.getItem('classHelperCleaningAssignments')),
    jobs: preserveJobTemplate(localStorage.getItem('classHelperJobAssignments')),
    schedule: preserveScheduleTemplate(localStorage.getItem('classHelperWeeklyScheduleV1'))
  }

  const removedKeys = removeClassDataRaw()

  if (templates.cleaning) setJson('classHelperCleaningAssignments', templates.cleaning)
  if (templates.jobs) setJson('classHelperJobAssignments', templates.jobs)
  if (templates.schedule) setJson('classHelperWeeklyScheduleV1', templates.schedule)

  const nextProfile = defaultClassProfile('')
  setJson(CLASS_PROFILE_KEY, nextProfile)
  localStorage.removeItem('className')
  localStorage.removeItem('students')

  window.dispatchEvent(new CustomEvent('class-helper-data-imported'))
  window.dispatchEvent(new CustomEvent('class-helper-class-ended', {
    detail: { previousProfile, nextProfile, removedKeys }
  }))

  return {
    previousProfile,
    profile: nextProfile,
    removedKeys,
    preservedTemplateKeys: Object.entries(templates)
      .filter(([, value]) => Boolean(value))
      .map(([key]) => key)
  }
}

export function getEndClassPreservedSettings() {
  return [
    'Firebase 連線設定與 Google 登入測試結果',
    '本機／個人 Firebase 儲存模式',
    '側欄排序與首頁顯示方式',
    '積分獎勵品項、音效與小組人數偏好',
    '作息時段，以及打掃區域與職務名稱模板'
  ]
}

export function getEndClassClearedData() {
  return [
    '學生名單與班級名稱',
    '簿本繳交、潔牙消毒與借閱紀錄',
    '積分紀錄、座位與分組',
    '行事曆事項與聯絡簿內容',
    '正式課表科目、打掃與職務的學生分配'
  ]
}

export function parseFirebaseConfig(input) {
  if (input && typeof input === 'object') return input
  let text = String(input || '').trim()
  if (!text) throw new Error('請貼上 Firebase Config')
  text = text.replace(/^```(?:js|javascript|json)?/i, '').replace(/```$/i, '').trim()
  const objectMatch = text.match(/\{[\s\S]*\}/)
  if (objectMatch) text = objectMatch[0]

  try {
    return JSON.parse(text)
  } catch {
    const converted = text
      .replace(/([,{]\s*)([A-Za-z_$][\w$]*)(\s*:)/g, '$1"$2"$3')
      .replace(/'/g, '"')
      .replace(/,\s*}/g, '}')
    try {
      return JSON.parse(converted)
    } catch {
      throw new Error('無法辨識 Firebase Config，請完整複製 firebaseConfig 的大括號內容')
    }
  }
}

export function getPersonalFirebaseConfig() {
  return safeJson(localStorage.getItem(FIREBASE_CONFIG_KEY), null)
}

export function savePersonalFirebaseConfig(configOrText) {
  const config = parseFirebaseConfig(configOrText)
  const required = ['apiKey', 'authDomain', 'databaseURL', 'projectId', 'appId']
  const missing = required.filter(key => !String(config?.[key] || '').trim())
  if (missing.length) throw new Error(`Firebase 設定缺少：${missing.join('、')}`)
  const allowed = ['apiKey', 'authDomain', 'databaseURL', 'projectId', 'storageBucket', 'messagingSenderId', 'appId', 'measurementId']
  const clean = Object.fromEntries(allowed.filter(key => config[key]).map(key => [key, String(config[key]).trim()]))
  clean.databaseURL = clean.databaseURL.replace(/\/$/, '')
  localStorage.setItem(FIREBASE_CONFIG_KEY, JSON.stringify(clean))
  return clean
}

export function removePersonalFirebaseConfig() {
  localStorage.removeItem(FIREBASE_CONFIG_KEY)
  localStorage.removeItem(FIREBASE_TEST_KEY)
  setStorageMode('local')
}

export function defaultWizardProgress() {
  return { currentStep: 1, completedSteps: [], acknowledged: false, updatedAt: '' }
}

export function getFirebaseWizardProgress() {
  const saved = safeJson(localStorage.getItem(FIREBASE_WIZARD_KEY), null)
  return { ...defaultWizardProgress(), ...(saved || {}) }
}

export function saveFirebaseWizardProgress(progress) {
  const clean = {
    ...defaultWizardProgress(),
    ...progress,
    currentStep: Math.min(7, Math.max(1, Number(progress?.currentStep) || 1)),
    completedSteps: Array.from(new Set((progress?.completedSteps || []).map(Number).filter(step => step >= 1 && step <= 7))),
    updatedAt: new Date().toISOString()
  }
  localStorage.setItem(FIREBASE_WIZARD_KEY, JSON.stringify(clean))
  return clean
}

export function getFirebaseTestResult() {
  return safeJson(localStorage.getItem(FIREBASE_TEST_KEY), null)
}

export function saveFirebaseTestResult(result) {
  const clean = { ...result, testedAt: new Date().toISOString() }
  localStorage.setItem(FIREBASE_TEST_KEY, JSON.stringify(clean))
  return clean
}

// 此常數只供測試與文件顯示，避免未來把教師偏好誤當班級資料。
export const TEMPLATE_KEYS_PRESERVED_ON_END = Array.from(TEMPLATE_PRESERVING_KEYS)
